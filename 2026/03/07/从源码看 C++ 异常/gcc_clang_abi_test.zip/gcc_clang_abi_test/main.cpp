#include <iostream>
#include <stdexcept>

extern "C" void gcc_catch_demo();

int main() {
    std::cout << "=== GCC 和 Clang 混合编译异常处理演示 ===" << std::endl;
    std::cout << "编译信息:" << std::endl;
    std::cout << "- main.cpp: 使用 Clang " << __clang_major__ << "." << __clang_minor__ << std::endl;
    
    try {
        std::cout << "\n[main] 调用 GCC 编译的函数..." << std::endl;
        gcc_catch_demo();
    } catch (const std::exception& e) {
        std::cout << "\n[main] 最终捕获: " << e.what() << std::endl;
    }
    
    std::cout << "\n=== 程序正常结束 ===" << std::endl;
    return 0;
}