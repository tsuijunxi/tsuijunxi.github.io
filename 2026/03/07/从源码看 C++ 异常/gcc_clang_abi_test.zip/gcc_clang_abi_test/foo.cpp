#include <iostream>
#include <stdexcept>

extern "C" void bar_function();  // 声明 bar.cpp 中的函数

extern "C" void gcc_throw_func() {
    std::cout << "[gcc] 在 gcc_throw_func 中，准备抛出异常..." << std::endl;
    throw std::runtime_error("这是从 GCC 编译的代码抛出的异常！");
}

extern "C" void gcc_catch_demo() {
    try {
        std::cout << "[gcc] 调用 bar.cpp 中的函数..." << std::endl;
        bar_function();  // 调用 clang 编译的函数
    } catch (const std::exception& e) {
        std::cout << "[gcc] 捕获到异常: " << e.what() << std::endl;
        throw;  // 重新抛出
    }
}