#!/bin/bash
set -e  # 出错时退出

echo "1. 编译 foo.cpp (使用 g++)..."
g++ -std=c++11 -fPIC -c foo.cpp -o foo.o
echo "   g++ 版本: $(g++ --version | head -1)"

echo -e "\n2. 编译 bar.cpp (使用 clang++)..."
clang++ -std=c++11 -fPIC -c bar.cpp -o bar.o
echo "   clang++ 版本: $(clang++ --version | head -1)"

echo -e "\n3. 编译 main.cpp (使用 clang++)..."
clang++ -std=c++11 -c main.cpp -o main.o

echo -e "\n4. 链接所有目标文件..."
echo "   使用 clang++ 作为链接器..."
clang++ -std=c++11 main.o foo.o bar.o -o mixed_app

echo -e "\n5. 编译信息摘要:"
echo "   - foo.o: 由 g++ 编译"
echo "   - bar.o: 由 clang++ 编译" 
echo "   - main.o: 由 clang++ 编译"
echo "   - 可执行文件: mixed_app"

echo -e "\n6. 检查文件类型:"
file foo.o bar.o main.o mixed_app

echo -e "\n7. 运行程序..."
echo "========================================"
./mixed_app