#include <iostream>
#include <stdexcept>

extern "C" void gcc_throw_func();  // 声明 foo.cpp 中的函数

extern "C" void bar_function() {
    std::cout << "[clang] 在 bar_function 中..." << std::endl;
    
    try {
        std::cout << "[clang] 调用 GCC 编译的函数（可能抛出异常）..." << std::endl;
        gcc_throw_func();  // 调用 gcc 编译的函数
    } catch (const std::runtime_error& e) {
        std::cout << "[clang] 捕获了 runtime_error: " << e.what() << std::endl;
        // 重新包装并抛出
        throw std::logic_error("clang: 重新抛出的逻辑错误");
    } catch (...) {
        std::cout << "[clang] 捕获了未知异常" << std::endl;
        throw;
    }
}