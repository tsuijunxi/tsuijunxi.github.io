#include <stdio.h>
#include "throw.h"

struct RAII {
    int i;
    RAII(int i) : i(i) {
         printf("RAII object %i has been built\n", i);
    }
    ~RAII() { 
        printf("RAII object %i has been destroyed\n", i);
     }
};

struct Exception {};

struct Derived_Exception : public Exception {};
void raise() {
    throw Derived_Exception();
}

void raiseWrapper() {
    raise();
}

void catchit() {
    try {
        RAII r(0);
        raiseWrapper();
    } catch(Exception&) {
        printf("Caught an Exception!\n");
    } catch(Derived_Exception&) {
        printf("Caught a Derived_Exception in catchit\n");
        throw;
    }
    printf("catchit handled the exception\n");
}

void seppukuInternal () {
        try {
            catchit();  
        } catch(Derived_Exception&) {
            printf("Caught a Derived_Exception in seppukuInternal ()\n");
            throw;
        }
    }

extern "C" {
    void seppuku() {
        try {
            seppukuInternal();  
        } catch(Derived_Exception&) {
            printf("Caught a Derived_Exception in seppuku!\n");
        }
    }
}

