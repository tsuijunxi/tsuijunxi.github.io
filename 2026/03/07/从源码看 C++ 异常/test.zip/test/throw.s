	.section	__TEXT,__text,regular,pure_instructions
	.build_version macos, 26, 0	sdk_version 26, 0
	.globl	__Z5raisev                      ; -- Begin function _Z5raisev
	.p2align	2
__Z5raisev:                             ; @_Z5raisev
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	mov	x0, #1                          ; =0x1
	bl	___cxa_allocate_exception
	adrp	x1, __ZTI17Derived_Exception@PAGE
	add	x1, x1, __ZTI17Derived_Exception@PAGEOFF
	mov	x2, #0                          ; =0x0
	bl	___cxa_throw
	.cfi_endproc
                                        ; -- End function
	.globl	__Z7catchitv                    ; -- Begin function _Z7catchitv
	.p2align	2
__Z7catchitv:                           ; @_Z7catchitv
Lfunc_begin0:
	.cfi_startproc
	.cfi_personality 155, ___gxx_personality_v0
	.cfi_lsda 16, Lexception0
; %bb.0:
	sub	sp, sp, #64
	stp	x29, x30, [sp, #48]             ; 16-byte Folded Spill
	add	x29, sp, #48
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
Ltmp0:
	bl	__Z5raisev
Ltmp1:
	b	LBB1_1
LBB1_1:
	b	LBB1_6
LBB1_2:
Ltmp2:
	stur	x0, [x29, #-8]
	mov	x8, x1
	stur	w8, [x29, #-12]
	b	LBB1_3
LBB1_3:
	ldur	w8, [x29, #-12]
	str	w8, [sp, #12]                   ; 4-byte Folded Spill
	subs	w8, w8, #2
	b.ne	LBB1_7
	b	LBB1_4
LBB1_4:
	ldur	x0, [x29, #-8]
	bl	___cxa_begin_catch
	str	x0, [sp, #16]
Ltmp8:
	adrp	x0, l_.str.1@PAGE
	add	x0, x0, l_.str.1@PAGEOFF
	bl	_printf
Ltmp9:
	b	LBB1_5
LBB1_5:
	bl	___cxa_end_catch
	b	LBB1_6
LBB1_6:
	adrp	x0, l_.str.2@PAGE
	add	x0, x0, l_.str.2@PAGEOFF
	bl	_printf
	ldp	x29, x30, [sp, #48]             ; 16-byte Folded Reload
	add	sp, sp, #64
	ret
LBB1_7:
	ldr	w8, [sp, #12]                   ; 4-byte Folded Reload
	subs	w8, w8, #1
	b.ne	LBB1_14
	b	LBB1_8
LBB1_8:
	ldur	x0, [x29, #-8]
	bl	___cxa_begin_catch
	str	x0, [sp, #24]
Ltmp3:
	adrp	x0, l_.str@PAGE
	add	x0, x0, l_.str@PAGEOFF
	bl	_printf
Ltmp4:
	b	LBB1_9
LBB1_9:
	bl	___cxa_end_catch
	b	LBB1_6
LBB1_10:
Ltmp5:
	stur	x0, [x29, #-8]
	mov	x8, x1
	stur	w8, [x29, #-12]
Ltmp6:
	bl	___cxa_end_catch
Ltmp7:
	b	LBB1_11
LBB1_11:
	b	LBB1_14
LBB1_12:
Ltmp10:
	stur	x0, [x29, #-8]
	mov	x8, x1
	stur	w8, [x29, #-12]
Ltmp11:
	bl	___cxa_end_catch
Ltmp12:
	b	LBB1_13
LBB1_13:
	b	LBB1_14
LBB1_14:
	ldur	x0, [x29, #-8]
	bl	__Unwind_Resume
LBB1_15:
Ltmp13:
	bl	___clang_call_terminate
Lfunc_end0:
	.cfi_endproc
	.section	__TEXT,__gcc_except_tab
	.p2align	2, 0x0
GCC_except_table1:
Lexception0:
	.byte	255                             ; @LPStart Encoding = omit
	.byte	155                             ; @TType Encoding = indirect pcrel sdata4
	.uleb128 Lttbase0-Lttbaseref0
Lttbaseref0:
	.byte	1                               ; Call site Encoding = uleb128
	.uleb128 Lcst_end0-Lcst_begin0
Lcst_begin0:
	.uleb128 Ltmp0-Lfunc_begin0             ; >> Call Site 1 <<
	.uleb128 Ltmp1-Ltmp0                    ;   Call between Ltmp0 and Ltmp1
	.uleb128 Ltmp2-Lfunc_begin0             ;     jumps to Ltmp2
	.byte	3                               ;   On action: 2
	.uleb128 Ltmp1-Lfunc_begin0             ; >> Call Site 2 <<
	.uleb128 Ltmp8-Ltmp1                    ;   Call between Ltmp1 and Ltmp8
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp8-Lfunc_begin0             ; >> Call Site 3 <<
	.uleb128 Ltmp9-Ltmp8                    ;   Call between Ltmp8 and Ltmp9
	.uleb128 Ltmp10-Lfunc_begin0            ;     jumps to Ltmp10
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp9-Lfunc_begin0             ; >> Call Site 4 <<
	.uleb128 Ltmp3-Ltmp9                    ;   Call between Ltmp9 and Ltmp3
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp3-Lfunc_begin0             ; >> Call Site 5 <<
	.uleb128 Ltmp4-Ltmp3                    ;   Call between Ltmp3 and Ltmp4
	.uleb128 Ltmp5-Lfunc_begin0             ;     jumps to Ltmp5
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp4-Lfunc_begin0             ; >> Call Site 6 <<
	.uleb128 Ltmp6-Ltmp4                    ;   Call between Ltmp4 and Ltmp6
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
	.uleb128 Ltmp6-Lfunc_begin0             ; >> Call Site 7 <<
	.uleb128 Ltmp12-Ltmp6                   ;   Call between Ltmp6 and Ltmp12
	.uleb128 Ltmp13-Lfunc_begin0            ;     jumps to Ltmp13
	.byte	5                               ;   On action: 3
	.uleb128 Ltmp12-Lfunc_begin0            ; >> Call Site 8 <<
	.uleb128 Lfunc_end0-Ltmp12              ;   Call between Ltmp12 and Lfunc_end0
	.byte	0                               ;     has no landing pad
	.byte	0                               ;   On action: cleanup
Lcst_end0:
	.byte	1                               ; >> Action Record 1 <<
                                        ;   Catch TypeInfo 1
	.byte	0                               ;   No further actions
	.byte	2                               ; >> Action Record 2 <<
                                        ;   Catch TypeInfo 2
	.byte	125                             ;   Continue to action 1
	.byte	3                               ; >> Action Record 3 <<
                                        ;   Catch TypeInfo 3
	.byte	0                               ;   No further actions
	.p2align	2, 0x0
                                        ; >> Catch TypeInfos <<
	.long	0                               ; TypeInfo 3
Ltmp14:                                 ; TypeInfo 2
	.long	__ZTI9Exception@GOT-Ltmp14
Ltmp15:                                 ; TypeInfo 1
	.long	__ZTI17Derived_Exception@GOT-Ltmp15
Lttbase0:
	.p2align	2, 0x0
                                        ; -- End function
	.section	__TEXT,__text,regular,pure_instructions
	.private_extern	___clang_call_terminate ; -- Begin function __clang_call_terminate
	.globl	___clang_call_terminate
	.weak_definition	___clang_call_terminate
	.p2align	2
___clang_call_terminate:                ; @__clang_call_terminate
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	___cxa_begin_catch
	bl	__ZSt9terminatev
	.cfi_endproc
                                        ; -- End function
	.globl	_seppuku                        ; -- Begin function seppuku
	.p2align	2
_seppuku:                               ; @seppuku
	.cfi_startproc
; %bb.0:
	stp	x29, x30, [sp, #-16]!           ; 16-byte Folded Spill
	mov	x29, sp
	.cfi_def_cfa w29, 16
	.cfi_offset w30, -8
	.cfi_offset w29, -16
	bl	__Z7catchitv
	ldp	x29, x30, [sp], #16             ; 16-byte Folded Reload
	ret
	.cfi_endproc
                                        ; -- End function
	.private_extern	__ZTS17Derived_Exception ; @_ZTS17Derived_Exception
	.section	__TEXT,__const
	.globl	__ZTS17Derived_Exception
	.weak_definition	__ZTS17Derived_Exception
__ZTS17Derived_Exception:
	.asciz	"17Derived_Exception"

	.private_extern	__ZTS9Exception         ; @_ZTS9Exception
	.globl	__ZTS9Exception
	.weak_definition	__ZTS9Exception
__ZTS9Exception:
	.asciz	"9Exception"

	.private_extern	__ZTI9Exception         ; @_ZTI9Exception
	.section	__DATA,__const
	.globl	__ZTI9Exception
	.weak_definition	__ZTI9Exception
	.p2align	3, 0x0
__ZTI9Exception:
	.quad	__ZTVN10__cxxabiv117__class_type_infoE+16
	.quad	__ZTS9Exception-9223372036854775808

	.private_extern	__ZTI17Derived_Exception ; @_ZTI17Derived_Exception
	.globl	__ZTI17Derived_Exception
	.weak_definition	__ZTI17Derived_Exception
	.p2align	3, 0x0
__ZTI17Derived_Exception:
	.quad	__ZTVN10__cxxabiv120__si_class_type_infoE+16
	.quad	__ZTS17Derived_Exception-9223372036854775808
	.quad	__ZTI9Exception

	.section	__TEXT,__cstring,cstring_literals
l_.str:                                 ; @.str
	.asciz	"Caught a Derived_Exception!\n"

l_.str.1:                               ; @.str.1
	.asciz	"Caught an Exception!\n"

l_.str.2:                               ; @.str.2
	.asciz	"catchit handled the exception\n"

.subsections_via_symbols
